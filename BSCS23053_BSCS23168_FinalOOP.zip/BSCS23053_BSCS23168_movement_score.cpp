#include "mygraphics.h"
#include "movement_score.h"
#include <string>
#include <fstream>
#include <iostream>
#include<time.h>
#include <ctime>
using namespace std;


movement_score::movement_score()   
{
	arr = nullptr;
	rows = 15;
	cols = 20;
	points = 0;
	highscore = 0;

}

movement_score::movement_score(char** Arr, int Rows, int Cols, int Points, int Highscore)  //Parametrized Constructor
{

	for (int i = 0; i < rows; i++)
	{
		for (int j = 0; j < cols; j++)
		{
			arr[i][j] = Arr[i][j];
		}
	}

	rows = Rows;
	cols = Cols;
	points = Points;
	highscore = Highscore;
}


movement_score::movement_score(movement_score& p) 
{
	for (int i = 0; i < rows; i++)
	{
		for (int j = 0; j < cols; j++)
		{
			this->arr[i][j] = p.arr[i][j];
		}
	}

	this->rows = p.rows;
	this->cols = p.cols;
	this->highscore = p.highscore;
	this->points = p.points;

}


void movement_score::setarr(char** Arr)  
{
	Arr = new char* [rows];

	for (int i = 0; i < rows; i++)
	{
		Arr[i] = new char[cols];
	}

	for (int i = 0; i < rows; ++i)
	{
		for (int j = 0; j < cols; ++j)
		{
			Arr[i][j] = NULL;
		}
	}

	this->arr = Arr;
}

void movement_score::set_points(int points)
{
	this->points = points;
}


void movement_score::set_highscore(int highscore)
{
	this->highscore = highscore;
}


int movement_score::get_points()
{
	return points;
}


int movement_score::get_highscore()
{
	return highscore;
}


bool movement_score::move_the_ghost(int pacman_row, int pacman_col, int ghost_row, int ghost_col, bool& flag, bool energized)
{

	int previous_row = ghost_row, previous_col = ghost_col;
	bool movement_one_direction = false;

	if (pacman_row > ghost_row) 
	{
		ghost_row++;
		movement_one_direction = true;
	}

	else if (pacman_row < ghost_row)   
	{
		movement_one_direction = true;

		ghost_row--;
	}

	if (arr[ghost_row][ghost_col] != 'x' && arr[ghost_row][ghost_col] != '|' && movement_one_direction)
	{

	}

	else
	{
		movement_one_direction = false;

		ghost_row = previous_row;
	}


	if (pacman_col > ghost_col && !movement_one_direction)  
	{
		ghost_col++;
	}

	else if (pacman_col < ghost_col && !movement_one_direction)   
	{
		ghost_col--;
	}

	if (arr[ghost_row][ghost_col] == 'P')
	{
		if (!energized)        
		{
			arr[pacman_row][pacman_col] = 'c';
			arr[previous_row][previous_col] = ' ';
			arr[0][0] = 'P';
			return false;
		}

		else          
		{
			points = points + 100;

			arr[previous_row][previous_col] = ' ';
			arr[8][8] = 'c';
			return true;
		}
	}

	bool see_pellot = false;


	if (arr[ghost_row][ghost_col] != 'x' && arr[ghost_row][ghost_col] != '|')
	{
		if (previous_row != ghost_row || previous_col != ghost_col)
		{
			if (arr[ghost_row][ghost_col] == 'o')
			{
				see_pellot = true;
			}
			arr[ghost_row][ghost_col] = 'c';


			if (flag == true)
			{
				arr[previous_row][previous_col] = 'o';

			}

			else
			{
				arr[previous_row][previous_col] = ' ';
			}
			flag = see_pellot;
		}

	}
	else
	{
		
	}


	return true;

}

bool movement_score::random_ghost_mov(bool& flag, bool energized) 
{
	int prow = 0;
	int pcol = 0;


	std::vector<std::pair<int, int>> ghost_positions;

	for (int i = 0; i < 15; i++) 
	{
		for (int j = 0; j < 20; j++) 
		{
			if (arr[i][j] == 'P') 
			{
				prow = i;
				pcol = j;
			}
			if (arr[i][j] == 'c' || arr[i][j] == 'g') 
			{
				ghost_positions.push_back({ i, j });
			}
		}
	}

	bool result = true;
	for (auto& pos : ghost_positions)
	{
		if (!move_single_ghost(prow, pcol, pos.first, pos.second, flag, energized)) 
		{
			result = false;
		}
	}

	return result;
}


void movement_score::COLOR()
{
	SetTextColor(LIGHTMAGENTA);

}


void movement_score::COLOR2()
{
	SetTextColor(LIGHTGREEN);
}

void movement_score::lose()     
{
	SetTextColor(CYAN);
	cls();
	gotoxy(0, 10);
	cout << "----------------------------------------------------GAME OVER----------------------------------------------------------" << endl;

}



int movement_score::yourscore(int x, int y)
{
	if (arr[x][y] == 'o')   
	{
		points = points + 10;

	}

	if (arr[x][y] == 'f')    
	{
		points = points + 50;
	}

	set_points(points);
	return points;

}

void movement_score::displayscore(int points)
{
	set_points(points);
	cout << "Current SCORE: " << get_points() << "\n";

	gotoxy(0, 26);

	cout << "HIGH SCORE: " << get_highscore() << "\n";
	cout << endl << endl;
}

void movement_score::set_pac_arr()         
{
	arr = new char* [rows];

	for (int i = 0; i < rows; i++)
	{
		arr[i] = new char[cols];
	}

	for (int i = 0; i < rows; i++)
	{
		for (int j = 0; j < cols; j++)
		{
			arr[i][j] = NULL;
		}
	}

	ifstream fin;

	fin.open("Pacman grid.txt");

	if (!fin.is_open())
	{
		cout << "FILE IS NOT OPEN" << endl;
	}


	for (int j = 0; j < 15; j++)
	{
		fin >> arr[j];
	}

	fin.close();

}


bool movement_score::move_the_pacman(int& i, int& j, int lastpos[], bool energized) 
{
	if (arr[i][j] == 'o') 
	{
		points += 10;
	}
	if (arr[i][j] == 'f') 
	{
		points += 50;
	}
	if (arr[i][j] == 'g' || arr[i][j] == 'c') 
	{
		if (!energized) 
		{
			arr[lastpos[0]][lastpos[1]] = ' ';
			arr[0][0] = 'P';
			return false;
		}
		else 
		{
			if (arr[i][j] == 'g') 
			{
				arr[8][10] = 'g';
			}
			else if (arr[i][j] == 'c')
			{
				arr[8][8] = 'c';
			}


			arr[i][j] = 'P';
			arr[lastpos[0]][lastpos[1]] = ' ';

			points += 50;

			return true;
		}
	}

	if (arr[i][j] != 'x' && arr[i][j] != '|') 
	{
		arr[i][j] = 'P';

		arr[lastpos[0]][lastpos[1]] = ' ';
	}
	else {
		i = lastpos[0];
		j = lastpos[1];
	}
	return true;
}


void movement_score::display_engine() 
{
	int i = 0, x1, x2, j = 0, y1, y2;


	for (i = 0, x1 = 8, x2 = 8, y1 = 1, y2 = 1; i < 15; i++) 
	{
		for (j = 0; j < 20; j++) 
		{
			switch (arr[i][j]) 
			{
			case 'o':
				drawEllipse(x1 + 5, y1 + 5, x2 + 20, y2 + 25, 0, 0, 0, 0, 0, 0);
				drawEllipse(x1 + 5, y1 + 10, x2 + 13, y2 + 18, 255, 255, 255, 255, 255, 255);
				break;
			case 'E':
				drawRectangle(x1 + 5, y1 + 5, x2 + 20, y2 + 25, 64, 224, 208, 64, 224, 208);
				break;
			case 'P':
				drawEllipse(x1 + 5, y1 + 5, x2 + 20, y2 + 25, 255, 255, 0, 255, 255, 0);
				break;
			case 'f':
				drawEllipse(x1 + 5, y1 + 5, x2 + 20, y2 + 25, 238, 130, 238, 238, 130, 238);
				break;
			case 'g':
			case 'c':
				drawEllipse(x1 + 5, y1 + 5, x2 + 20, y2 + 25, 255, 0, 0, 255, 0, 0);
				break;
			case 'x':
				drawLine(x1, y1, x2 + 30, y2, 0, 0, 255);
				break;
			case '|':
				drawLine(x1, y1, x2, y2 + 10, 0, 0, 255);
				break;
			case ' ':
				drawRectangle(x1 + 5, y1 + 5, x2 + 20, y2 + 25, 0, 0, 0, 0, 0, 0);
				drawEllipse(x1 + 5, y1 + 5, x2 + 20, y2 + 25, 0, 0, 0, 0, 0, 0);
				break;
			}
			x1 += 43;
			x2 += 43;
		}
		x1 = 5;
		x2 = 5;
		y1 += 32;
		y2 += 32;
	}
	gotoxy(0, 25);
	displayscore(get_points());
}


void movement_score::movement_of_pacman()
{

	cls();
	int w = 0, h = 0;
	getWindowDimensions(w, h);

	cls();
	showConsoleCursor(false);


	bool rebound = false;          
	bool go_up = false;
	bool do_vertical_movement = false;
	bool first_print = false;
	int last_pos[2];
	int i = 0, j = 0;
	int  blocked = false;      
	int b = 0;          

	bool flag = false;
	int slow_down_ghost = 2;

	bool energized = false;
	int energy = 50;

	bool win = true;

	for (int life = 3; life > 0;)   
	{
		drawLine(0, 3, w, 3, 0, 0, 255);  
		drawLine(0, h, w, h, 0, 0, 255);  
		drawLine(3, h, 3, 0, 0, 0, 255);  
		drawLine(w, 0, w, h, 0, 0, 255);  



		delay(100);
		char last = arr[i][j];		
		last_pos[0] = i;
		last_pos[1] = j;


		display_engine();

		bool moved = false;

		if (go_up == true && do_vertical_movement == true && i > 0)
		{
			moved = true;
			i--;

		}

		else if (go_up == false && do_vertical_movement == true && i < 14)
		{
			moved = true;

			i++;

		}

		else if (j < 19 && !rebound && do_vertical_movement == false)
		{
			moved = true;

			j++;

		}

		else if (rebound == true && j > 0 && do_vertical_movement == false)
		{
			moved = true;

			j--;
		}
		char c = getKey();



		if (arr[i][j] == 'E')
		{
			energized = true;
		}

		if (energized)
		{
			energy--;

			gotoxy(50, 26);
			cout << "PACMAN ENERGIZED";

			gotoxy(50, 27);

			cout << "REMAINING ENERGY= " << energy;

			if (energy == 10)
			{
				cls();
			}
		}

		if (energy == 0)
		{
			cls();
			energy = 50;
			energized = false;

		}


		if (moved)
		{

			if (move_the_pacman(i, j, last_pos, energized) == false)
			{
				c = 27;		
			}


		}

		if (slow_down_ghost == 0)
		{


			if (random_ghost_mov(flag, energized) == false)  
			{
				c = 27;		
			}
			slow_down_ghost = 2;
		}

		else
		{
			slow_down_ghost--;

		}


		if (c == 13)      
		{
			break;
		}

		if (c == 27)
		{
			i = 0;
			j = 0;

			cls();

			gotoxy(35, 15);
			cout << "------------YOU HAVE LOST ONE LIFE--------------" << endl;


			set_highscore(points);

			delay(1000);
			cls();

			c = 'd';

			life--;

			if (life == 0)     
			{
				c = 13;
			}

		}

		if (c == 'd' || c == '6' || c == 'l' || (GetAsyncKeyState(VK_RIGHT)))      
		{

			rebound = false;
			do_vertical_movement = false;
		}

		else if (c == 'a' || c == '4' || c == 'j' || (GetAsyncKeyState(VK_LEFT)))       
		{

			rebound = true;
			do_vertical_movement = false;

		}

		else if (c == 's' || c == '2' || c == 'k' || (GetAsyncKeyState(VK_DOWN)))       
		{

			go_up = false;
			do_vertical_movement = true;

		}

		else if (c == 'w' || c == '8' || c == 'i' || (GetAsyncKeyState(VK_UP)))         //Up Movement
		{

			go_up = true;
			do_vertical_movement = true;

		}

		SetTextColor(YELLOW);


		gotoxy(1, 27);
		cout << "LIVES REMAINING: " << life;
		if (life == 0)
		{
			showConsoleCursor(true);
			cout << "-----------GAME OVER---------------";

			lose();
			displayscore(get_points());
			break;
			points = 0;
		}



		if (points >= 2380)        
		{


			win = true;

			if (win == true)
			{
				cls();
				SetTextColor(BLUE);
				gotoxy(0, 15);
				cout << "----------------------------------------------Congratulations! You Won!------------------------------------------------" << endl << endl;

			}
			break;

		}


	}

}



void movement_score::output()
{
	SetTextColor(LIGHTGREEN);
	cout << "......................................................GAME RULES........................................................" << endl << endl << endl;
	SetTextColor(YELLOW);
	cout << "1. PAC-MAN only has 3 lives in this game. Once a ghost catches PAC-MAN, then you lose a life." << endl;

	cout << "2. Once 3 Lives are over, Game Ends" << endl;

	cout << "3. PAC-MAN earns 10 points for the white pegs that it eats, 50 points for fruits, and 100 points to eat the Ghosts" << endl;

	cout << "4. Work on clearing all the white pegs in one corner of the board before moving on to other corners" << endl;

	cout << "5. Use your Energizer Wisely. After eating Energizer Pacman can eat Ghosts for 50 seconds" << endl;

	cout << "6. You win the Game once you Eat all the white pegs and Fruits" << endl;

}

bool movement_score::move_single_ghost(int pacman_row, int pacman_col, int& ghost_row, int& ghost_col, bool& flag, bool energized) 
{
	int previous_row = ghost_row, previous_col = ghost_col;

	bool movement_one_direction = false;

	if (pacman_row > ghost_row) 
	{
		ghost_row++;
		movement_one_direction = true;
	}

	else if (pacman_row < ghost_row) 
	{
		ghost_row--;
		movement_one_direction = true;
	}

	if (arr[ghost_row][ghost_col] != 'x' && arr[ghost_row][ghost_col] != '|' && movement_one_direction) 
	{
		
	}
	else
	{
		movement_one_direction = false;
		ghost_row = previous_row;
	}

	if (pacman_col > ghost_col && !movement_one_direction) 
	{
		ghost_col++;
	}
	else if (pacman_col < ghost_col && !movement_one_direction) 
	{
		ghost_col--;
	}

	if (arr[ghost_row][ghost_col] == 'P') 
	{
		if (!energized) {
			arr[pacman_row][pacman_col] = 'c';
			arr[previous_row][previous_col] = ' ';
			arr[0][0] = 'P';
			return false;
		}
		else {
			points += 100;
			arr[previous_row][previous_col] = ' ';
			ghost_row = 8;
			ghost_col = 8; 
			return true;
		}
	}

	bool see_pellot = false;

	if (arr[ghost_row][ghost_col] != 'x' && arr[ghost_row][ghost_col] != '|') 
	{
		if (previous_row != ghost_row || previous_col != ghost_col)
		{
			if (arr[ghost_row][ghost_col] == 'o') 
			{
				see_pellot = true;
			}
			arr[ghost_row][ghost_col] = 'c';

			if (flag == true) {
				arr[previous_row][previous_col] = 'o';
			}
			else {
				arr[previous_row][previous_col] = ' ';
			}
			flag = see_pellot;
		}
	}

	return true;
}


movement_score::~movement_score()  
{
	for (int i = 0; i < cols; i++)
	{
		delete[] arr[i];
	}

	delete[] arr;
	arr = nullptr;

}