#pragma once
#include<iostream>
#include "mygraphics.h"
#include<string>
#include<vector>
using namespace std;

class movement_score

{
protected:
	char** arr;
	int rows;
	int cols;
	int points;
	int highscore;
	int ghost_rows[4];
	int ghost_cols[4];

public:

	movement_score();
	movement_score(char** arr, int rows, int cols, int points, int highscore);
	movement_score(movement_score& p);
	void set_points(int points);
	void set_highscore(int highscore);
	int get_points();
	int get_highscore();
	void setarr(char** arr);
	void movement_of_pacman();
	void set_pac_arr();
	void display_engine();
	void COLOR();
	void COLOR2();
	void lose();
	bool move_the_ghost(int prow, int pcol, int grow, int gcol, bool& flag, bool);
	bool random_ghost_mov(bool& flag, bool);
	int yourscore(int x, int y);
	void displayscore(int points);
	bool move_the_pacman(int& x, int& y, int arr[], bool energized);
	bool move_single_ghost(int pacman_row, int pacman_col, int& ghost_row, int& ghost_col, bool& flag, bool energized);
	virtual void output();
	~movement_score();
};