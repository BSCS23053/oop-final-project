#include <iostream>
#include "menu.h"
#include "movement_score.h"

void menu::set_start(char start)
{
	this->start = start;
}

char  menu::get_start()
{
	return start;
}

void menu::output()
{
	cout << endl << endl << endl;
	cout << "........................................................................................................................" << endl;
	cout << " ..............................................TO START GAME PRESS  'S'................................................." << endl;

	set_start(start);
	for (int i = 0; i < 3; i++)
	{
		cin >> start;
		if (start == 's' || start == 'S') 
		{
			set_pac_arr();
			movement_of_pacman();

		}
		if (start == 'c')
		{
			set_pac_arr();
			start = 's ';
			continue;
		}

		if (start == 't' || start == 'T')  
		{
			displayscore(points);
		}

		if (start == 'm' || start == 'M')  
		{
			set_highscore(highscore);
			displayscore(points);
			set_pac_arr();
			movement_of_pacman();

		}
	}
}